### Hexlet tests and linter status:
[![Actions Status](https://github.com/nail685/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/nail685/python-project-49/actions)

Programm have 2 games: brain-even add brain-calc.
Brain-even - you must indicate the correct answer whether the number is even or not.
Brain-calc - you must indicate the correct result of addition, subtraction and multiplication. 

download: git clone https://github.com/nail685/python-project-49.git\

install:

Example asciinema:
