### Hexlet tests and linter status:
[![Actions Status](https://github.com/nail685/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/nail685/python-project-49/actions)

download: git clone https://github.com/nail685/python-project-49.git\
