### Hexlet tests and linter status:
[![Actions Status](https://github.com/nail685/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/nail685/python-project-49/actions)

Programm have 2 games: brain-even add brain-calc.
Brain-even - you must indicate the correct answer whether the number is even or not.
Brain-calc - you must indicate the correct result of addition, subtraction and multiplication. 

Play five games and try to win in all of it!

INSTALLATION:

Install using pip:

pip install git+https://github.com/nail685/python-project-49.git\

INSTRUCTIONS:

This is a five math games:

1. Even numbers
You must indicate the correct answer whether the number is even or no.
To start the game run brain-even.

2. Calculator
You must indicate the correct result of addition, subtraction and multiplication.
To start the game run brain-calc.

3. Greatest common dividor
To win this game you have to find a GCD of three pairs of numbers.
To start the game run brain-gcd.

4. Prime numbers
To win this game you have to give an answer ig given number prime or not.
To start the game run brain-prime.

5. Progression
To win this game you have to find the missing number in progression.
To start the game run brain-progression.

EXAMPLE ASCIINEMA:
